public final class $(type-name)SeqHolder
{

    public $(scoped-actual-type-name) value[] = null;

    public $(type-name)SeqHolder()
    {
    }

    public $(type-name)SeqHolder($(scoped-actual-type-name)[] initialValue)
    {
        value = initialValue;
    }

}
