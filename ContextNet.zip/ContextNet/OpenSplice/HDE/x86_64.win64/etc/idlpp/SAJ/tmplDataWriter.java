public interface $(type-name)DataWriter extends
    $(scoped-type-name)DataWriterOperations,
    DDS.DataWriter
{
}
