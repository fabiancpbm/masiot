public final class $(type-name)TypeSupportHolder
{

    public $(scoped-type-name)TypeSupport value = null;

    public $(type-name)TypeSupportHolder()
    {
    }

    public $(type-name)TypeSupportHolder($(scoped-type-name)TypeSupport initialValue)
    {
        value = initialValue;
    }

}
