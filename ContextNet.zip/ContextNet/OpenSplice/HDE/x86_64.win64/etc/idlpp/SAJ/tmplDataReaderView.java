public interface $(type-name)DataReaderView extends
    $(scoped-type-name)DataReaderViewOperations,
    DDS.DataReaderView
{
}
