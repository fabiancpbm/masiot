public final class $(type-name)DataReaderViewHolder
{

    public $(scoped-type-name)DataReaderView value = null;

    public $(type-name)DataReaderViewHolder()
    {
    }

    public $(type-name)DataReaderViewHolder($(scoped-type-name)DataReaderView initialValue)
    {
        value = initialValue;
    }

}
