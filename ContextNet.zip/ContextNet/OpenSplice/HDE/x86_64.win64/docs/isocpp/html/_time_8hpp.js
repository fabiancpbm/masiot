var _time_8hpp =
[
    [ "Time", "classdds_1_1core_1_1_time.html", "classdds_1_1core_1_1_time" ],
    [ "operator+", "_time_8hpp.html#ac71ed8afa092791cb66235ea8fc2e349", null ],
    [ "operator+", "_time_8hpp.html#a8a333c7b790031b08eb28612cf05372d", null ],
    [ "operator-", "_time_8hpp.html#ac8a8e680fb610dba3199e3169b3e5c7f", null ]
];