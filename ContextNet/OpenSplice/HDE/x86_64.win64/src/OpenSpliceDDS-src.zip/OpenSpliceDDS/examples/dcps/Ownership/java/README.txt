[=== STANDALONE ===]
4) Build the example
--------------------
5) Run the example
------------------
[--- POSIX ---]
4) Build the example 
--------------------
Open a terminal. Navigate to the example folder.
DDS environment variables must be set, source the appropriate script
"release.com" supplied with the distribution.
Execute the script BUILD. Two executables are generated in the bld folder when the example 
is built: 
  . PublisherRunner
  . Subscriber

5) Run the example
------------------
DDS environment variables must be set, source the appropriate script
"release.com" supplied with the distribution.
  - Start OpenSplice
  - Open a terminal and execute the script RUN

[=== CORBA ===]
4) Build the example
--------------------
5) Run the example
------------------











