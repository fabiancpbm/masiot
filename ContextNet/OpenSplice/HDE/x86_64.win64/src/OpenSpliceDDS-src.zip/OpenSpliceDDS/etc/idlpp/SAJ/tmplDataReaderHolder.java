public final class $(type-name)DataReaderHolder
{

    public $(scoped-type-name)DataReader value = null;

    public $(type-name)DataReaderHolder()
    {
    }

    public $(type-name)DataReaderHolder($(scoped-type-name)DataReader initialValue)
    {
        value = initialValue;
    }

}
