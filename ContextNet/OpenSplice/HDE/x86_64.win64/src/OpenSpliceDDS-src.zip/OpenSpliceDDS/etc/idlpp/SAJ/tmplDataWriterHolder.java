public final class $(type-name)DataWriterHolder
{

    public $(scoped-type-name)DataWriter value = null;

    public $(type-name)DataWriterHolder()
    {
    }

    public $(type-name)DataWriterHolder($(scoped-type-name)DataWriter initialValue)
    {
        value = initialValue;
    }

}
