public interface $(type-name)DataReader extends
    $(scoped-type-name)DataReaderOperations,
    DDS.DataReader
{
}
