public final class $(type-name)MetaHolder
{

    public static java.lang.String metaDescriptor[] = { $(meta-descriptor) };

    public $(type-name)MetaHolder()
    {
    }

}
